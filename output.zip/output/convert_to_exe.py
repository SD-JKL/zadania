print("Hello, World!")
input("Press Enter to exit...")

